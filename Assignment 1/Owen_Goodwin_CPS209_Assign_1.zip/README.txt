Car Dealership Simulator
--------------------------
Owen Goodwin (500909196)
For CPS209
03/20/19
--------------------------
It works on my machine ¯\_(ツ)_/¯  
You should have no issues running this, everything works as intended.
Just make sure you've got a cars.txt the program can read from in your working dir, and you're good to go!
